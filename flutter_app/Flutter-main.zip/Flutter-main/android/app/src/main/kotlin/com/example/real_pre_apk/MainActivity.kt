package com.example.real_pre_apk

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
