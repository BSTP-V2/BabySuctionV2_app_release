# BaBy Suciton V2


---
## Workflow แนะนำ:
- git pull / git fetch ก่อนจะ commit ทุกครั้ง เพื่อป้องกันให้โค้ดไม่ชนกัน
- เพิ่ม / แก้ไขนิดหน่อยก็ให้ commit หรือ push เลย งานแต่ละคนในทีมจะได้สัมพันธ์กัน
![git-teamwork](/assets/images/git-teamwork-tip.png)

---

## Commit msg tip:
- `feat:` ของใหม่
- `fix:` แก้บัค
- `docs:` แก้เอกสาร
- `refactor:` แก้ไขโค้ดแต่ผลลัพธ์เดิม
- `chore:` งานจิปาถะ
### ตัวอย่าง 
    git commit -m "feat: เพิ่มฟังก์ชัน taeGooner"






Project Structure: BSTP V2 🍼 สอแสสกุนเต้

lib/<br>
├── 📁 pages/<br>
│<br>
│   └── 📁 babies/<br>
│       ├── 📄 babies_list.dart — หน้ารายชื่อเด็กทั้งหมด<br>
│       ├── 📄 baby_route_hub.dart — เมนูหลักของเด็กแต่ละคน<br>
│       ├── 📄 baby_test_history.dart — ประวัติการทดสอบย้อนหลัง<br>
│       ├── 📄 comparision_test_history.dart — เปรียบเทียบผลการทดสอบ<br>
│       ├── 📄 during_test.dart — หน้าทดสอบแบบ Real-time<br>
│       ├── 📄 setup_test.dart — ตั้งค่าก่อนเริ่มทดสอบ<br>
│       ├── 📄 specific_test_history.dart — รายละเอียดผลทดสอบรายครั้ง<br>
│       └── 📄 sumary_test.dart — สรุปผลหลังจบทดสอบ<br>
│<br>
├── 📁 bluetooth/<br>
│   ├── 📄 connected_device.dart — จัดการอุปกรณ์ที่เชื่อมต่อ<br>
│   └── 📄 finding_devices.dart — ค้นหาอุปกรณ์ ESP32<br>
│<br>
├── 📁 services/<br>
│   ├── 📄 babies_list_dialog_handler.dart — จัดการ Popup/Dialog<br>
│   ├── 📄 ble_handler.dart — จัดการ Bluetooth BLE<br>
│   ├── 📄 database_handler.dart — จัดการฐานข้อมูล SQLite<br>
│   ├── 📄 suction_test_handler.dart — คำนวณและวิเคราะห์แรงดูด<br>
│   └── 📄 ui_helper.dart — รวม Widget และ Theme กลาง<br>
│<br>
└── 📄 main.dart — จุดเริ่มต้นของแอป<br>






<h2>🍼 BSTP V2 Team Members</h2>
<img width="1448" height="1086" alt="img" src="https://github.com/user-attachments/assets/6110f678-6866-4221-a0ba-d496c3e6807f" />






<img width="504" height="656" alt="image" src="https://github.com/user-attachments/assets/d0d0c7f3-a862-4c8e-a99e-36b6d4bd2c2f" />







